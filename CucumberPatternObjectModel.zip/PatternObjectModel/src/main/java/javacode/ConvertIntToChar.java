package javacode;

public class ConvertIntToChar {

	public static void main(String[] args) {

				String txt = "1234";
				System.out.println(txt);

				int num = Integer.parseInt(txt);
				System.out.println(num);

				String text = String.valueOf(num);
				System.out.println(text);

			}


	}


